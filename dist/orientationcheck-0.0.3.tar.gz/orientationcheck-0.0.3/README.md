# liveness_orientation_check

face liveness orientation detection activate, the script asks the person to generate an action, for example the action can be turn your face to the right,or turn your face to the left. The actions are requested randomly, after fulfilling all the actions it generates a message saying "liveness successful" or "liveness fail".


# How to install:

<pre><code>pip install -r requirements.txt </code></pre>

<pre><code>python liveness_orientation_detection.py </code></pre>
